package domain;

public interface Surveyer {

}
