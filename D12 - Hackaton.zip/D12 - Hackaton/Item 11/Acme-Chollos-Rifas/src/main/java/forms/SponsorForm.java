
package forms;

public class SponsorForm extends ActorForm {
	
}
