
package forms;

public class ModeratorForm extends ActorForm {
	
}
