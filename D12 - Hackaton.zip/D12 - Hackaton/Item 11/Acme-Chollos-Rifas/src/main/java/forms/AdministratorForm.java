package forms;

public class AdministratorForm extends ActorForm {

}