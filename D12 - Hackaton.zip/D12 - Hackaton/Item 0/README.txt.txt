Hemos introducido A+ utilizados en proyectos anteriores, como son:
	- Bootstrap v3.3.7
	- Protocolo HTTPS
	- Pageable
	- Incorporaci�n de HTML5